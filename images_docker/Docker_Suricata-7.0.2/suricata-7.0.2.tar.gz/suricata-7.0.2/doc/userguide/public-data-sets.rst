Public Data Sets
================

Collections of pcaps for testing and profiling.

DARPA sets: https://www.ll.mit.edu/r-d/datasets?author=All&rdarea=All&rdgroup=All&keywords=cyber&tag=All&items_per_page=10

MAWI sets (pkt headers only, no payloads): http://mawi.wide.ad.jp/mawi/samplepoint-F/2012/

MACCDC: http://www.netresec.com/?page=MACCDC

Netresec: http://www.netresec.com/?page=PcapFiles

Wireshark: https://gitlab.com/wireshark/wireshark/-/wikis/SampleCaptures

Security Onion collection: https://securityonion.net/docs/Pcaps

Stratosphere IPS. Malware Capture Facility Project: https://stratosphereips.org/category/dataset.html
