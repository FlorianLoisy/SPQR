Performance
===========

.. toctree::

   runmodes
   packet-capture
   tuning-considerations
   hyperscan
   high-performance-config
   statistics
   ignoring-traffic
   packet-profiling
   rule-profiling
   tcmalloc
   analysis
